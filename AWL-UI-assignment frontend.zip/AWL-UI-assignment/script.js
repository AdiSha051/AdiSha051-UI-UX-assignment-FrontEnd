document.addEventListener('DOMContentLoaded', function() {
    const paymentRadios = document.querySelectorAll('input[name="payment"]');
    const cardDetails = document.querySelector('.card-details');
  
    paymentRadios.forEach(radio => {
      radio.addEventListener('change', function() {
        if (this.value === 'visa') {
          cardDetails.classList.remove('hidden');
        } else {
          cardDetails.classList.add('hidden');
        }
      });
    });
  });
  
  $(function () {
    // Set form height on document ready
    // setFormHeight(); 
  
    // Set up formatting for Credit Card fields
    $('#credit .cc-number').formatCardNumber();
  });